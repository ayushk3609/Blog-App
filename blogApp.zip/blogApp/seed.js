const mongoose = require('mongoose')
const Blog = require('./models/blog')

const blogs = [{
    title:"Taj Mahal",
    image:"https://images.unsplash.com/photo-1524473994769-c1bbbf30e944?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80",
    author:"Kaushik",
    description:"The Taj Mahal was commissioned by Shah Jahan in 1631, to be built in the memory of his wife Mumtaz Mahal, who died on 17 June that year, while giving birth to their 14th child, Gauhara Begum.[9][10] Construction started in 1632,[11] and the mausoleum was completed in 1648, while the surrounding buildings and garden were finished five years later.[12] The imperial court documenting Shah Jahan's grief after the death of Mumtaz Mahal illustrates the love story held as the inspiration for the Taj Mahal."
},
{
    title:"Hawa Mahal",
    image:"https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Hawa_Mahal_Final_1.jpg/1024px-Hawa_Mahal_Final_1.jpg",
    author:"Ayush",
    description:'Hawa Mahal  "The Palace of Winds" or "The Palace of Breeze") is a palace in Jaipur, India approximately 300 kilometers from the capital city of Delhi. Built from red and pink sandstone, the palace sits on the edge of the City Palace, Jaipur, and extends to the Zenana, or women chambers.'
}
]

const seedDB = async()=>{
    await Blog.insertMany(blogs)
    console.log('DB Seeded')
}

module.exports = seedDB