const express = require('express')
const router = express.Router()
const Blog = require('../models/blog')
const Comment = require('../models/comment')
const {isLoggedIn} = require('../middleware')

router.get('/blogs',async(req,res)=>{
    try{
        const blogs = await Blog.find({})
        res.render('blogs/index',{blogs})
    }
    catch(e){
        console.log("Something went wrong")
        req.flash("error","Blog Not Found")
        res.redirect("/error")
    }
})

router.get('/blogs/new',isLoggedIn,(req,res)=>{
    res.render('blogs/new')
})


router.post('/blogs',isLoggedIn,async (req,res)=>{
    try{
        const {blog} = req.body
        await Blog.create(blog)
        req.flash("success","Blog Uploaded Successfully")
        res.redirect("/blogs")
    }
    catch(e){
        console.log("Something went wrong")
        req.flash("error","Unable to Create New Blog")
        res.redirect("/error")
    }
})

router.get("/blogs/:id",async(req,res)=>{
    try{
        const {id} = req.params
        const blog = await Blog.findById(id).populate('comments')
        res.render("blogs/show",{blog})
    }
    catch(e){
        console.log("Something went wrong")
        req.flash("error",e.message)
        res.redirect("/error")
    }
})

router.get("/blogs/:id/edit" ,isLoggedIn,async(req,res)=>{
    const {id} = req.params
    const blog = await Blog.findById(id)
    res.render("blogs/edit",{blog})
})

router.patch("/blogs/:id",isLoggedIn,async(req,res)=>{
   try{
        const {id} = req.params
        const {blog} = req.body
        await Blog.findByIdAndUpdate(id,blog)
        req.flash("success","Your Blog Has Been Updated :)")
        res.redirect(`/blogs/${req.params.id}`)
   }
   catch(e){
    console.log(e.message)
    req.flash('error',"Blog Updation failed!")
    res.redirect('/error')
   }
})

router.delete("/blogs/:id",isLoggedIn,async(req,res)=>{
    const {id} = req.params
    await Blog.findByIdAndDelete(id)
    res.redirect("/blogs")
})

router.get("/error",(req,res)=>{
    res.render("error")
})

router.post('/blogs/:id/comment',isLoggedIn,async(req,res)=>{
    try{
        const blog = await Blog.findById(req.params.id)
        const comment = new Comment({
            user:req.user.username,
            ...req.body
        })
        blog.comments.push(comment)
        await comment.save()
        await blog.save()
        res.redirect(`/blogs/${req.params.id}`)
    }
    catch(e){
        console.log(e.message)
        res.flash('error','Cannot Post Your Comment!!')
        res.redirect('/error')
    }
  })

  module.exports = router
